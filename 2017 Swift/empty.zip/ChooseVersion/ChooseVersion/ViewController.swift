//
//  ViewController.swift
//  ChooseVersion
//
//  Created by smallHappy on 2017/8/7.
//  Copyright © 2017年 SmallHappy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var dataArray: [String]!
    var result: String!
    
    var titleLabel: UILabel!
    var pickerView: UIPickerView!
    var answerLabel: UILabel!
    var answerButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.initData()
        self.initUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setUI()
    }
    
    //MARK: - function
    private func initUI() {
        //TODO: - todo
        
        self.titleLabel = UILabel()
        self.titleLabel.text = "請問目前的作業系統為何？"
        self.titleLabel.textAlignment = .center
        self.view.addSubview(self.titleLabel)
        
        self.pickerView = UIPickerView()
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        self.pickerView.selectRow(self.getPickerViewSelection(), inComponent: 0, animated: true)
        self.view.addSubview(self.pickerView)
        
        self.answerLabel = UILabel()
        self.answerLabel.text = "答案？"
        self.answerLabel.textAlignment = .center
        self.view.addSubview(self.answerLabel)
        
        self.answerButton = UIButton()
        self.answerButton.setTitle("回答答案", for: .normal)
        self.answerButton.setTitleColor(UIColor.darkGray, for: .normal)
        //TODO: - todo
        self.answerButton.addTarget(self, action: #selector(self.onButtonAction(_:)), for: .touchUpInside)
        //TODO: - todo
        self.view.addSubview(self.answerButton)
    }
    
    private func setUI() {
        let frameW = UIScreen.main.bounds.width
//        let frameH = UIScreen.main.bounds.height
        let gap: CGFloat = 10
        
        let labelH: CGFloat = 20
        self.titleLabel.frame = CGRect(x: 0, y: 20, width: frameW, height: labelH)
        
        let pickerX = frameW * (1 / 6)
        let pickerY = self.titleLabel.frame.origin.y + self.titleLabel.frame.height + gap
        let pickerW = frameW * (2 / 3)
        let pickerH: CGFloat = 130
        self.pickerView.frame = CGRect(x: pickerX, y: pickerY, width: pickerW, height: pickerH)
        
        let answerY = self.pickerView.frame.origin.y + self.pickerView.frame.height + gap
        self.answerLabel.frame = CGRect(x: 0, y: answerY, width: frameW, height: labelH)
        
        let buttonY = self.answerLabel.frame.origin.y + self.answerLabel.frame.height + gap
        let buttonW = frameW - gap * 2
        let buttonH: CGFloat = 30
        self.answerButton.frame = CGRect(x: gap, y: buttonY, width: buttonW, height: buttonH)
    }
    
    private func initData() {
        //TODO: - todo
        result = self.dataArray[0]
    }
    
    private func getPickerViewSelection() -> Int {
        //TODO: - todo
    }
    
    //MARK: - selector
    func onButtonAction(_ sender: UIButton) {
        //TODO: - todo
    }

}

extension ViewController: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if row >= self.dataArray.count { return "" }
        return self.dataArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if row >= self.dataArray.count { return }
        //TODO: - todo
    }
    
}

extension ViewController: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.dataArray.count
    }
    
}
