//
//  TvModel.swift
//  DemoUITableView
//
//  Created by smallHappy on 2017/8/18.
//  Copyright © 2017年 SmallHappy. All rights reserved.
//

import UIKit

class TvModel: NSObject {
    
    //TODO: - 待處理

    var program = [String]()
    var news = [String]()
    var sports = [String]()
    var recreations = [String]()
    
    func setProgramData(jsonObject: Any?) throws {
        //TODO: - 待處理
        self.program = program
    }
    
    func setNewsData(jsonObject: Any?) throws {
        //TODO: - 待處理
        self.news = news
    }
    
    func setSportsData(jsonObject: Any?) throws {
        //TODO: - 待處理
        self.sports = sports
    }
    
    func setRecreationsData(jsonObject: Any?) throws {
        //TODO: - 待處理
        self.recreations = recreations
    }
    
}
