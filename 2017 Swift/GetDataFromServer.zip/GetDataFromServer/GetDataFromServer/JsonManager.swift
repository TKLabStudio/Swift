//
//  JsonManager.swift
//  GetDataFromServer
//
//  Created by TK on 2017/12/12.
//  Copyright © 2017年 TK. All rights reserved.
//

import UIKit

class JsonManager: NSObject {

    private static let instance = JsonManager()
    static var shared: JsonManager{
        return self.instance
    }
    
    enum HTTPMethod: String {
        case get = "GET", post = "POST"
    }
    
    func getJsonObj(method: HTTPMethod = .post, url: URL, body: Data? = nil, second: Double = 15, finish: ((Any?) -> Void)? = nil) {//做完之後傳值給finish（專門做結束的動作），也可以不給
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: second) //reloadIgnoringLocalAndRemoteCacheData忽略所有暫存
        request.httpMethod = method.rawValue
        request.httpBody = body //httpBody允許填入nil

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            //取得資料失敗
            if let error = error {
                print("Error:", error)
                finish?(nil)
                return
            }
            guard let data = data else {
                print("data is nil")
                finish?(nil)
                return
            }
            //取得資料成功
            do{
              finish?(try JSONSerialization.jsonObject(with: data, options: .mutableContainers))
                print("Success!!")
            } catch {
                print("Error:", error) //error是catch自帶有的
                finish?(nil)
            }
        }
        task.resume() //送出
    }
}
