//
//  UVModel.swift
//  GetDataFromServer
//
//  Created by TK on 2017/12/12.
//  Copyright © 2017年 TK. All rights reserved.
//

import UIKit

class UVModel: NSObject {
    
    struct UV: Codable {
        var County: Srting?
        var PublishAgency: Srting?
        var PublishTime: Srting?
        var SiteName: Srting?
        var UVI: Srting?
        var WGS84Lat: Srting?
        var WGS84Lon: Srting?
    }
    var array = [UV]()
    
    func steJsonData(jsonObj: Any?) {
        guard let jsonObj = jsonObj as? [Any] else {
            return
        }
        self.array.removeAll()
        for dictionary in jsonObj {
            guard let dictionary = dictionary as? [String:String] else {
                continue
            }
            let uv = UV().self
        }
    }
}
