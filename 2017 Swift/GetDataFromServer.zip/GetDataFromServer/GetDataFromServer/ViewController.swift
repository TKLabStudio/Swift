//
//  ViewController.swift
//  GetDataFromServer
//
//  Created by TK on 2017/12/12.
//  Copyright © 2017年 TK. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var loadingAnimatingView: LoadingAnimatingView!
    override func viewDidLoad() {
        super.viewDidLoad()
        loadingAnimatingView = LoadingAnimatingView()
        self.view.addSubview(loadingAnimatingView)
        }
    
    override func viewWillAppear(_ animated: Bool) {
        guard let url = URL(string: "http://opendata2.epa.gov.tw/UV/UV.json") else { return }
        self.loadingAnimatingView.start()
        JsonManager.shared.getJsonObj(method: .get, url: url) { (jsonObj) in
        self.loadingAnimatingView.stop()
            print(jsonObj ?? "jsonObj is nil")
    }
    }

}

