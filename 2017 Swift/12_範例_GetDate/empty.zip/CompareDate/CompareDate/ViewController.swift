//
//  ViewController.swift
//  CompareDate
//
//  Created by smallHappy on 2017/8/7.
//  Copyright © 2017年 SmallHappy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var yearColumn: ColumnView!
    var monthColumn: ColumnView!
    var dayColumn: ColumnView!
    var button: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.initUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setUI()
    }

    //MARK: - function
    func initUI() {
        self.yearColumn = ColumnView()
        self.yearColumn.titleLabel.text = "年 year"
        self.view.addSubview(self.yearColumn)
        
        self.monthColumn = ColumnView()
        self.monthColumn.titleLabel.text = "月 month"
        self.view.addSubview(self.monthColumn)
        
        self.dayColumn = ColumnView()
        self.dayColumn.titleLabel.text = "日 day"
        self.view.addSubview(self.dayColumn)
        
        self.button = UIButton()
        self.button.setTitle("取得日期資訊", for: .normal)
        self.button.setTitleColor(UIColor.white, for: .normal)
//        self.button.backgroundColor = UIColor(red: 33 / 255, green: 82 / 255, blue: 134 / 255, alpha: 1)
        self.button.addTarget(self, action: #selector(self.onButtonAction), for: .touchUpInside)
        self.view.addSubview(self.button)

    }
    
    func setUI() {
        let frameW = UIScreen.main.bounds.width
//        let frameH = UIScreen.main.bounds.height
        
        let gap: CGFloat = 10
        let columnW = frameW - 10 - 10
        let columnH: CGFloat = 50
        var _frame = CGRect.zero
        
        _frame = CGRect(x: gap, y: 20, width: columnW, height: columnH)
        self.yearColumn.frame = _frame
        _frame.origin.y += (columnH + gap)
        self.monthColumn.frame = _frame
        _frame.origin.y += (columnH + gap)
        self.dayColumn.frame = _frame
        _frame.origin.y += (columnH + gap)
        self.button.frame = _frame
    }

    //MARK: - selector
    func onButtonAction() {
        
    }

}

