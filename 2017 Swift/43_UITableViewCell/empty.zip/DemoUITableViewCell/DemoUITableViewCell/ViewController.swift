//
//  ViewController.swift
//  DemoUITableViewCell
//
//  Created by smallHappy on 2017/8/25.
//  Copyright © 2017年 SmallHappy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //TODO: - 待完成
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.initData()
        self.initUI()
    }
    
    //MARK: - fcuntion
    private func initData() {
        self.imageArray = [UIImage?]()
        for i in 1 ... 36 {
            let image = UIImage(named: String(format: "%03d", i))
            self.imageArray.append(image)
        }
    }
    
    private func initUI() {
        self.view.backgroundColor = UIColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.0)
        
        self.tableView = UITableView(frame: CGRect(
            x: 10,
            y: 20,
            width: UIScreen.main.bounds.width - 20,
            height: UIScreen.main.bounds.height - 30)
        )
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.layer.cornerRadius = 8.0
        self.view.addSubview(self.tableView)
    }
    
    //MARK: - selector
    //TODO: - 待完成

}

extension ViewController: UITableViewDelegate {
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.imageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellID = "reusableCellIdentifier"
        //TODO: - 待完成
        return cell!
    }
    
}
